const socket = io.connect();
let chat = document.getElementById("chat");
let username;
document.getElementById("welcome").style.display = "none";
document.getElementById("chat-page").style.display = "none";

document.getElementById("form").onsubmit = function (e) {
  e.preventDefault();
  if (!document.getElementById("username").value == "") {
    username = document.getElementById("username").value;
    validateUsername(username);
    document.getElementById("login").style.display = "none";
    document.getElementById("welcome").style.display = "flex";
    document.getElementById("welcome-title").innerHTML = `Hello ${username}`;

    //Mejorable con una promesa probablemente ->
    setTimeout(() => {
      document.getElementById("welcome").style.animationName = "dissapear";
      document.getElementById("welcome").style.animationDuration = "1s";
      document.getElementById("welcome").style.animationIterationCount =
        "initial";
      document.getElementById("welcome").style.animationTimingFunction =
        "ease-in";
    }, 2000);
    setTimeout(() => {
      document.getElementById("chat-page").style.display = "flex";
    }, 2000);
    setTimeout(() => {
      document.getElementById("welcome").style.display = "none";
    }, 2999);
  }
};

document.getElementById("input-container").onsubmit = function (e) {
  e.preventDefault();
  if (!document.getElementById("message").value == "") {
    let message = document.getElementById("message").value;
    validateMsg(message);
    socket.emit("message", username, message);
    document.getElementById("message").value = "";
    message = "";
  }
};

socket.on("newmsg", (data) => {
  chat.innerHTML = "";
  data.forEach((e) => {
    const { username, message, color } = e;
    const messageElement = document.createElement("div");
    messageElement.classList.add("movie");
    messageElement.innerHTML = `<div class="message"><p class="${color}">${username}:</p> <p>${message}</p></div>`;
    chat.appendChild(messageElement);
    return;
  });
  chat.scrollBy(0, 100);
});

function validateUsername(data) {
  if (data.includes("<", ">", "*", "/")) {
    data = "";
    alert("Characters like < > * / are not allowed");
    document.location.reload();
  } else if (data.includes(" ")) {
    data = "";
    alert("Spaces are not allowed");
    document.location.reload();
  } else if (data === null) {
    data = "";
  }
}
function validateMsg(data) {
  if (data.includes("<", ">", "*", "/")) {
    data = "";
    alert("Characters like < > * / are not allowed");
    document.location.reload();
  } else if (data === null) {
    data = "";
  }
}
